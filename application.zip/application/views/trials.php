 <!-- Main Content -->
 <div class="main-content">
        <section class="section">
          <div class="section-body">
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4><?= $title ?></h4>
                  </div>
                  <div class="card-body">
                  <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#addModel" style="margin-top:-5%;">Add Trial</button>
                      <!-- start messages --->
                      <div style="text-align: center">
                              <?php if($feedback =$this->session->flashdata('feedback')){
                                $feedback_class =$this->session->flashdata('feedbase_class');  ?>
                                    <div class="row">
                                      <div class="col-md-6 col-md-offset-6 msg">
                                      <div class="alert alert-dismissible <?=  $feedback_class;?>">
                                      <?= $feedback ?>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                      </button>
                                      </div>
                                      </div>
                                  </div>    
                                <?php }?>
                            </div>
                    <!-- end of messages  --->
                    <div class="table-responsive">
                      <table class="table table-striped table-hover" id="tableExport" style="width:100%;">
                        <thead class="">
                          <tr>
                            <th>Event Name</th>
                            <th>Trial Year</th>
                            <th>Trial Start Date</th>
                            <th>Trial End Date</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <?php if(!empty($trials)):?>
                            <tbody>
                            <?php foreach($trials as $onByOne):?>
                                <tr>
                                    <td><?= $onByOne->event_title?></td>
                                    <td><?= $onByOne->trial_year?></td>
                                    <td><?= $onByOne->trial_start_date?></td>
                                    <td><?= $onByOne->trial_end_date?></td>
                                    <td>
                                       <a class="fa fa-edit text-info" data-toggle="modal" data-target="#editModel" href="javascript:void(0)" onclick="trial_update(<?=$onByOne->trial_id?>)"></a>

                                        <a class="fa fa-trash text-danger" onclick="return confirm('Are you sure to delete?')" href="<?= base_url('admin/trial_delete/'.$onByOne->trial_id) ?>"></a>
                                    </td>
                                </tr>
                            <?php endforeach;?>
                            </tbody>
                        <?php endif; ?>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>

      
        <!-- add form -->
        <div class="modal fade" id="addModel"  role="dialog" aria-labelledby="formModaladd" aria-hidden="true" data-backdrop="static">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header bg-info">
                    <h5 class="modal-title text-white" id="formModaladd">Add Trial </h5>
                    <button type="button" class="close text-danger" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    </div>
                    <div class="modal-body">
                    <!-- body-->
                        <form class="" method="post" action="<?=base_url("admin/trial_insert") ?>">
                            
                            <div class="form-group">
                                  <label>Trial Name</label>
                                  
                                  <select  name="event_id" class="form-control">
                                    
                                    <option>Select event</option>

                                    <?php if(!empty($events)):

                                      foreach($events as $event):?>

                                    <option value="<?=$event->event_id?>"><?=$event->event_title?></option>
                                  <?php endforeach;endif;?>
                                  </select>
                                  
                                </div>

                                <div class="form-group">
                                  <label>Trial Start Date</label>
                                  <input type="date" class="form-control" placeholder="Trial Start Date" name="trial_start_date" required>
                                  
                                </div>

                                <div class="form-group">
                                  <label>Trial End Date</label>
                                  <input type="date" class="form-control " placeholder="Trial End Date" name="trial_end_date" required>
                                  
                                </div>

                                <div class="form-group">
                                  <label>Trial Year</label>
                                  <input type="date" class="form-control" placeholder="Trial Year" name="trial_year" required>
                                  
                                </div>
                                <button type="submit" class="btn btn-primary m-t-15 waves-effect">Save</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!--- edit form -->
      <div class="modal fade" id="editModel"  role="dialog" aria-labelledby="formModaladd" aria-hidden="true" data-backdrop="static">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header bg-info">
                    <h5 class="modal-title text-white" id="formModaladd">Update Event </h5>
                    <button type="button" class="close text-danger" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    </div>
                    <div class="modal-body">
                    <!-- body-->
                        <form class="" method="post" action="<?= base_url("admin/trial_update") ?>">
                            <div class="form-group">
                                  <label>Trial Name</label>
                                  <select  name="event_id" class="form-control" id="edit_event_id">
                                    <option>Select event</option>
                                    <?php if(!empty($events)):
                                      foreach($events as $event):?>
                                    <option value="<?=$event->event_id?>"><?=$event->event_title?></option>
                                  <?php endforeach;endif;?>
                                  </select>
                                  
                                </div>

                                <div class="form-group">
                                  <label>Trial Start Date</label>
                                  <input type="date" class="form-control" placeholder="Trial Start Date" id="edit_trial_start_date" name="trial_start_date" required>
                                  
                                </div>

                                <div class="form-group">
                                  <label>Trial End Date</label>
                                  <input type="date" class="form-control " placeholder="Trial End Date" id="edit_trial_end_date" name="trial_end_date" required>
                                  
                                </div>

                                <div class="form-group">
                                  <label>Trial Year</label>
                                  <input type="date" class="form-control" placeholder="Trial Year" name="trial_year"id="edit_trial_year" required>
                                  
                                </div>
                                <input type="hidden" name="trial_id" id="edit_trial_id" >
                                <button type="submit" class="btn btn-primary m-t-15 waves-effect">Save</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

      <script>
          function trial_update(trial_id){ 
          $.ajax({
            url: 'admin/get_ajax_trial/'+trial_id,
            dataType: 'json',
            success: function(response){
              console.log(response);
              $('#edit_event_id option[value='+response.event_id+']').attr('selected','selected'); 
              $('#edit_trial_year').val(response.trial_year);
              $('#edit_trial_start_date').val(response.trial_start_date); 
              $('#edit_trial_end_date').val(response.trial_end_date); 
              $('#edit_trial_id').val(trial_id); 
            }
          });
        }
      </script>